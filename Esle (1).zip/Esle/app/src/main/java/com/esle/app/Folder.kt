package com.esle.app

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.File

object Folder {
    data class Listing(val name: String, val videos: List<VideoItem>, val allNames: Set<String>)

    fun list(ctx: Context, tree: Uri): Listing? {
        val dir = DocumentFile.fromTreeUri(ctx, tree) ?: return null
        val files = dir.listFiles()
        val videos = files.mapNotNull { f ->
            val n = f.name ?: return@mapNotNull null
            if (f.isFile && Formats.ext(n) in Formats.video) VideoItem(n, f.uri) else null
        }
        return Listing(dir.name ?: "", videos, files.mapNotNull { it.name }.toSet())
    }
}

data class ApplyResult(val renamedVideos: Int, val writtenSubs: Int, val errors: List<String>)

object Renamer {
    fun apply(ctx: Context, tree: Uri, rows: List<PlanRow>, toUtf8: Boolean): ApplyResult {
        val dir = DocumentFile.fromTreeUri(ctx, tree)
            ?: return ApplyResult(0, 0, listOf("Klasöre erişilemedi"))
        val resolver = ctx.contentResolver
        var renamed = 0
        var written = 0
        val errors = mutableListOf<String>()

        for (row in rows) {
            val video = row.video ?: continue

            // 1) Video adını değiştir (yalnızca önek modunda)
            val target = row.newVideoName
            if (target != null && target != video.name) {
                val clash = dir.findFile(target)
                if (clash != null) {
                    errors += "${video.name}: '$target' adı zaten kullanılıyor"
                    continue
                }
                try {
                    val result = DocumentsContract.renameDocument(resolver, video.uri, target)
                    if (result == null) {
                        errors += "${video.name}: yeniden adlandırılamadı"
                        continue
                    }
                    renamed++
                } catch (e: Exception) {
                    errors += "${video.name}: ${e.message ?: "yeniden adlandırılamadı"}"
                    continue
                }
            }

            // 2) Altyazıyı videonun yanına yeni adıyla yaz
            val sub = row.sub
            val subName = row.newSubName
            if (sub != null && subName != null) {
                try {
                    writeSubtitle(ctx, dir, subName, sub.file, toUtf8)
                    written++
                } catch (e: Exception) {
                    errors += "$subName: ${e.message ?: "yazılamadı"}"
                }
            }
        }
        return ApplyResult(renamed, written, errors)
    }

    private fun writeSubtitle(ctx: Context, dir: DocumentFile, name: String, src: File, toUtf8: Boolean) {
        var bytes = src.readBytes()
        if (toUtf8 && Formats.isTextSubtitle(Formats.ext(name), bytes)) {
            bytes = TextFix.toUtf8(bytes)
        }
        val target = dir.findFile(name) ?: createNamed(dir, name)
        val out = ctx.contentResolver.openOutputStream(target.uri, "wt")
            ?: error("Yazma için açılamadı")
        out.use { it.write(bytes) }
    }

    private fun createNamed(dir: DocumentFile, name: String): DocumentFile {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(Formats.ext(name))
            ?: "application/octet-stream"
        val file = dir.createFile(mime, name) ?: error("Dosya oluşturulamadı")
        // Bazı sağlayıcılar uzantıyı kendi eklediği için adı kontrol edip düzeltiriz.
        if (file.name != name) file.renameTo(name)
        return file
    }
}
