package com.esle.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EsleTheme {
                EsleScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EsleScreen(vm: MainViewModel = viewModel()) {
    val st by vm.state.collectAsStateWithLifecycle()
    var subsExpanded by remember { mutableStateOf(false) }

    val pickDir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.onDirPicked(uri)
    }
    val pickSubs = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.onSubsPicked(uris)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Eşle") }) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.navigationBarsPadding()) {
                    if (st.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Button(
                        onClick = vm::applyChanges,
                        enabled = !st.busy && st.readyCount > 0,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                    ) {
                        Text(if (st.readyCount > 0) "Uygula (${st.readyCount})" else "Uygula")
                    }
                }
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                StepCard(
                    number = 1,
                    title = "Video klasörü",
                    info = when {
                        st.dirUri == null -> "Dizi bölümlerinin olduğu klasör"
                        else -> "${st.dirName} · ${st.videos.size} video"
                    },
                    button = if (st.dirUri == null) "Seç" else "Değiştir",
                    onClick = { pickDir.launch(null) },
                )
            }

            item {
                StepCard(
                    number = 2,
                    title = "Altyazılar",
                    info = if (st.subs.isEmpty()) {
                        "srt, ass, vtt… ya da zip / rar / 7z"
                    } else {
                        "${st.selectedSubCount} / ${st.subs.size} altyazı seçili"
                    },
                    button = if (st.subs.isEmpty()) "Seç" else "Değiştir",
                    onClick = { pickSubs.launch(arrayOf("*/*")) },
                ) {
                    st.loadErrors.forEach {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    if (st.subs.isNotEmpty()) {
                        TextButton(onClick = { subsExpanded = !subsExpanded }) {
                            Text(if (subsExpanded) "Listeyi gizle" else "Altyazıları tek tek seç")
                        }
                    }
                }
            }

            if (subsExpanded && st.subs.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { vm.setAllSubs(true) }) { Text("Tümünü seç") }
                        TextButton(onClick = { vm.setAllSubs(false) }) { Text("Hiçbiri") }
                    }
                }
                items(st.subs, key = { it.key }) { sub ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.toggleSub(sub.key) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = sub.key !in st.excluded, onCheckedChange = { vm.toggleSub(sub.key) })
                        Column(Modifier.weight(1f)) {
                            Text(sub.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                sub.label,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Adlandırma", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = st.prefix,
                            onValueChange = vm::setPrefix,
                            label = { Text("Ortak ad (örn. housemd)") },
                            supportingText = { Text("Boş bırakırsan altyazılar video adını alır") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        if (st.prefix.isNotBlank()) {
                            OutlinedTextField(
                                value = st.start,
                                onValueChange = vm::setStart,
                                label = { Text("Başlangıç numarası") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                            )
                            SwitchRow("Sıfırla doldur (01, 02…)", st.pad, vm::setPad)
                        }
                        SwitchRow("Altyazıyı UTF-8'e çevir (Türkçe karakterler için)", st.toUtf8, vm::setUtf8)
                    }
                }
            }

            if (st.rows.isNotEmpty()) {
                item {
                    Text(
                        "Önizleme",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                items(st.rows) { row ->
                    PreviewRow(row, st.dirNames)
                    HorizontalDivider()
                }
            }
        }
    }

    st.error?.let { msg ->
        AlertDialog(
            onDismissRequest = vm::dismissError,
            confirmButton = { TextButton(onClick = vm::dismissError) { Text("Tamam") } },
            text = { Text(msg) },
        )
    }

    st.result?.let { r ->
        AlertDialog(
            onDismissRequest = vm::dismissResult,
            confirmButton = { TextButton(onClick = vm::dismissResult) { Text("Tamam") } },
            title = { Text(if (r.errors.isEmpty()) "Tamamlandı" else "Bitti, bazı hatalar var") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${r.writtenSubs} altyazı yazıldı, ${r.renamedVideos} video yeniden adlandırıldı.")
                    r.errors.take(8).forEach {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    if (r.errors.size > 8) Text("… ve ${r.errors.size - 8} hata daha")
                }
            },
        )
    }
}

@Composable
private fun StepCard(
    number: Int,
    title: String,
    info: String,
    button: String,
    onClick: () -> Unit,
    content: @Composable ColumnScope.() -> Unit = {},
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(28.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("$number", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        info,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.width(8.dp))
                FilledTonalButton(onClick = onClick) { Text(button) }
            }
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PreviewRow(row: PlanRow, dirNames: Set<String>) {
    val error = MaterialTheme.colorScheme.error
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val transparent = ListItemDefaults.colors(containerColor = Color.Transparent)

    when {
        row.video == null -> ListItem(
            colors = transparent,
            headlineContent = { Text("Eşleşen video yok", color = error) },
            supportingContent = { Text(row.sub?.name.orEmpty(), color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        )
        else -> {
            val videoTitle = row.newVideoName ?: row.video.name
            ListItem(
                colors = transparent,
                headlineContent = { Text(videoTitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = {
                    Column {
                        if (row.newVideoName != null && row.newVideoName != row.video.name) {
                            Text("önce: ${row.video.name}", color = muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (row.newSubName != null) {
                            val overwrite = row.newSubName in dirNames
                            Text(
                                "↳ ${row.newSubName}" + if (overwrite) "  (üzerine yazılır)" else "",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        } else {
                            Text("Altyazı bulunamadı", color = error)
                        }
                    }
                },
            )
        }
    }
}
