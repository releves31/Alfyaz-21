package com.esle.app

/** Bir video ile bir altyazının eşleşmesi; taraflardan biri eksik olabilir. */
data class Match(val video: VideoItem?, val sub: SubItem?)

/** Önizlemede gösterilen ve uygulanan satır. null alan = "değiştirme". */
data class PlanRow(
    val video: VideoItem?,
    val sub: SubItem?,
    val newVideoName: String?,
    val newSubName: String?,
) {
    val isPair: Boolean get() = video != null && sub != null
}

object Matcher {
    /**
     * Önce SxxExx / 1x02 gibi bölüm bilgisine göre eşler (iki taraf da tamamen tanınıyorsa),
     * olmazsa doğal sıralamaya göre sırayla eşler.
     */
    fun match(videos: List<VideoItem>, subs: List<SubItem>): List<Match> {
        val vs = videos.sortedWith { a, b -> naturalCompare(a.name, b.name) }
        val ss = subs.sortedWith { a, b -> naturalCompare(a.name, b.name) }

        val vKeys = vs.map { episodeKey(it.name) }
        val sKeys = ss.map { episodeKey(it.name) }
        val canUseKeys = vs.isNotEmpty() && ss.isNotEmpty() &&
            vKeys.all { it != null } && sKeys.all { it != null } &&
            vKeys.toSet().size == vKeys.size && sKeys.toSet().size == sKeys.size

        if (canUseKeys) {
            val subByKey = ss.associateBy { episodeKey(it.name)!! }
            val used = mutableSetOf<Int>()
            val paired = vs.map { v ->
                val k = episodeKey(v.name)!!
                val s = subByKey[k]
                if (s != null) used += k
                Match(v, s)
            }
            val leftovers = ss.filter { episodeKey(it.name)!! !in used }.map { Match(null, it) }
            return paired + leftovers
        }

        val n = maxOf(vs.size, ss.size)
        return List(n) { Match(vs.getOrNull(it), ss.getOrNull(it)) }
    }
}

object Planner {
    private val illegal = Regex("""[\\/:*?"<>|]""")

    /**
     * [prefixRaw] boşsa: video adı korunur, altyazı video adını alır.
     * Doluysa: ikisi de "<önek><sayı>" olur (housemd1.mp4 + housemd1.srt).
     */
    fun plan(matches: List<Match>, prefixRaw: String, start: Int, pad: Boolean): List<PlanRow> {
        val prefix = prefixRaw.trim().replace(illegal, "")
        val videoCount = matches.count { it.video != null }
        val width = if (pad) maxOf(2, (start + videoCount - 1).toString().length) else 0
        var n = start

        return matches.map { m ->
            val v = m.video
            val s = m.sub
            when {
                v == null -> PlanRow(null, s, null, null)
                prefix.isEmpty() -> PlanRow(
                    video = v,
                    sub = s,
                    newVideoName = null,
                    newSubName = s?.let { Formats.baseName(v.name) + "." + Formats.ext(it.name) },
                )
                else -> {
                    val base = prefix + n.toString().padStart(width, '0')
                    n++
                    PlanRow(
                        video = v,
                        sub = s,
                        newVideoName = base + "." + Formats.ext(v.name),
                        newSubName = s?.let { base + "." + Formats.ext(it.name) },
                    )
                }
            }
        }
    }
}
