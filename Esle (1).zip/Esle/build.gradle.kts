// AGP 9 Kotlin'i kendi içinde derler; ayrı "kotlin.android" eklentisi gerekmez.
plugins {
    id("com.android.application") version "9.5.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
}
