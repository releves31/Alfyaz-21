# Eşle

Dizi bölümlerini ve altyazılarını tek seferde aynı adla eşleyen Android uygulaması.
Jetpack Compose + Material 3, minSdk 26, compileSdk/targetSdk 37.

## Nasıl çalışır
1. **Video klasörünü** seç (mp4, mkv, avi, mov, wmv, flv, webm, m4v, mpg, ts, 3gp… tanınır).
2. **Altyazıları** seç: tek tek `srt, ass, ssa, vtt, sub, idx, smi, sbv, ttml, dfxp, sup` ya da doğrudan **zip / rar / 7z** (içinden sadece altyazılar çıkarılır).
3. **Adlandırma**:
   - Ortak ad boşsa: altyazılar video adını alır (`House.S01E01.mkv` → `House.S01E01.srt`).
   - Ortak ad yazarsan (`housemd`): ikisi de `housemd1.mp4` + `housemd1.srt`, `housemd2…` olur. İstersen `01, 02` şeklinde sıfırla doldurur, başlangıç numarasını seçebilirsin.
4. Önizlemeyi kontrol edip **Uygula**.

Eşleştirme: dosya adlarında `S01E02` / `1x02` varsa bölüm numarasına göre, yoksa doğal sıralamaya göre (ep2 < ep10) sırayla.
Birden çok dilli arşivlerde "Altyazıları tek tek seç" ile istemediklerini kaldırabilirsin.

Altyazı videonun yanına **kopyalanır** (orijinal arşiv dokunulmaz). "UTF-8'e çevir" açıkken Windows-1254 (Türkçe) altyazılar da bozulmadan çevrilir.

## Derleme
Android Studio'da klasörü aç (Gradle senkronu yapılır). Wrapper jar'ı yoksa Studio'nun
önerdiği Gradle sürümünü kullan ya da terminalde `gradle wrapper` çalıştır.
AGP 9.5.0 / Gradle 9.8.2 / Kotlin 2.4.21 / Compose 1.12.1. Studio daha yeni sürüm önerirse yükseltmek sorun çıkarmaz.

## Bilinen sınırlar
- RAR5 arşivler (junrar kütüphanesi RAR4'ü destekler): hata mesajı çıkar, zip/7z'e çevirmek gerekir.
- Android 11+ sistem kuralı: `Download` / sürücü kök klasörü ve `Android/data` seçilemez; alt klasör seç.
- İçinde arşiv olan arşivler (zip içinde rar) açılmaz.
- `.idx` + `.sub` (VobSub) çiftleri ayrı iki altyazı olarak görünür.
- Bu kod burada derlenemedi (ağ kapalı, Android SDK yok); ilk derlemede küçük bir düzeltme gerekebilir.
