package com.esle.app

import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

data class VideoItem(val name: String, val uri: Uri)

/** [file] önbellekteki (cache) çıkarılmış kopya, [label] listede gösterilen kaynak bilgisi. */
data class SubItem(val name: String, val file: File, val label: String) {
    val key: String get() = file.absolutePath
}

object Formats {
    val video = setOf(
        "mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "mpg", "mpeg",
        "ts", "m2ts", "mts", "3gp", "ogv", "divx", "vob", "rmvb",
    )

    val subtitle = setOf(
        "srt", "ass", "ssa", "vtt", "sub", "idx", "smi", "sami", "sbv", "ttml", "dfxp", "sup",
    )

    val archive = setOf("zip", "rar", "7z")

    /** Metin tabanlı olduğu kesin olan altyazı türleri (UTF-8'e çevrilebilir). */
    private val textSubtitle = setOf("srt", "ass", "ssa", "vtt", "smi", "sami", "sbv", "ttml", "dfxp")

    fun ext(name: String): String = name.substringAfterLast('.', "").lowercase()

    fun baseName(name: String): String = name.substringBeforeLast('.', name)

    /** .sub hem MicroDVD (metin) hem VobSub (ikili) olabilir; NUL baytı varsa ikilidir. */
    fun isTextSubtitle(ext: String, bytes: ByteArray): Boolean =
        ext in textSubtitle ||
            (ext == "sub" && bytes.asSequence().take(4096).none { it == 0.toByte() })
}

object TextFix {
    /** UTF-8 ise olduğu gibi (BOM'suz), UTF-16 BOM'luysa çevirerek, değilse Windows-1254 (Türkçe) varsayarak UTF-8 üretir. */
    fun toUtf8(b: ByteArray): ByteArray {
        if (b.size >= 2) {
            if (b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) {
                return String(b, 2, b.size - 2, Charsets.UTF_16LE).toByteArray(Charsets.UTF_8)
            }
            if (b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) {
                return String(b, 2, b.size - 2, Charsets.UTF_16BE).toByteArray(Charsets.UTF_8)
            }
        }
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val text = try {
            decoder.decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1254"))
        }
        return text.removePrefix("﻿").toByteArray(Charsets.UTF_8)
    }
}

/** 1, 2, 10 gibi sayıları sayı olarak karşılaştıran sıralama (ep2 < ep10). */
fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        val ca = a[i]
        val cb = b[j]
        if (ca.isDigit() && cb.isDigit()) {
            var ei = i
            while (ei < a.length && a[ei].isDigit()) ei++
            var ej = j
            while (ej < b.length && b[ej].isDigit()) ej++
            val na = a.substring(i, ei).trimStart('0')
            val nb = b.substring(j, ej).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
            i = ei
            j = ej
        } else {
            val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

private val episodePatterns = listOf(
    Regex("""[Ss](\d{1,2})[ ._-]?[Ee](\d{1,3})"""),
    Regex("""(?<![\dA-Za-z])(\d{1,2})[xX](\d{2,3})(?![\dA-Za-z])"""),
    Regex("""[Ss]eason[ ._-]?(\d{1,2}).{0,12}?[Ee]pisode[ ._-]?(\d{1,3})""", RegexOption.IGNORE_CASE),
)

/** "S01E02" / "1x02" gibi kalıplardan sezon*1000+bölüm üretir; bulamazsa null. */
fun episodeKey(name: String): Int? {
    for (p in episodePatterns) {
        val m = p.find(name) ?: continue
        val season = m.groupValues[1].toInt()
        val episode = m.groupValues[2].toInt()
        return season * 1000 + episode
    }
    return null
}
