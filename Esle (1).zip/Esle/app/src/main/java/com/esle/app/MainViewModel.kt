package com.esle.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val dirUri: Uri? = null,
    val dirName: String = "",
    val videos: List<VideoItem> = emptyList(),
    val dirNames: Set<String> = emptySet(),
    val subs: List<SubItem> = emptyList(),
    val excluded: Set<String> = emptySet(),
    val loadErrors: List<String> = emptyList(),
    val prefix: String = "",
    val start: String = "1",
    val pad: Boolean = false,
    val toUtf8: Boolean = true,
    val rows: List<PlanRow> = emptyList(),
    val busy: Boolean = false,
    val result: ApplyResult? = null,
    val error: String? = null,
) {
    val selectedSubCount: Int get() = subs.count { it.key !in excluded }
    val readyCount: Int get() = rows.count { it.video != null && (it.sub != null || it.newVideoName != null) }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val ctx get() = getApplication<Application>()

    private fun refresh(s: UiState): UiState {
        val activeSubs = s.subs.filter { it.key !in s.excluded }
        val matches = Matcher.match(s.videos, activeSubs)
        val rows = Planner.plan(matches, s.prefix, s.start.toIntOrNull() ?: 1, s.pad)
        return s.copy(rows = rows)
    }

    private fun mutate(f: (UiState) -> UiState) = _state.update { refresh(f(it)) }

    fun onDirPicked(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (e: Exception) {
            // Kalıcı izin alınamazsa da bu oturumda çalışmaya devam eder.
        }
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = null) }
            val listing = withContext(Dispatchers.IO) { Folder.list(ctx, uri) }
            if (listing == null) {
                _state.update { it.copy(busy = false, error = "Klasöre erişilemedi. Başka bir klasör seçin.") }
            } else {
                mutate {
                    it.copy(
                        busy = false,
                        dirUri = uri,
                        dirName = listing.name,
                        videos = listing.videos,
                        dirNames = listing.allNames,
                        error = if (listing.videos.isEmpty()) "Bu klasörde desteklenen bir video dosyası yok." else null,
                    )
                }
            }
        }
    }

    fun onSubsPicked(uris: List<Uri>) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true, error = null) }
            val loaded = withContext(Dispatchers.IO) { SubtitleLoader.load(ctx, uris) }
            mutate {
                it.copy(
                    busy = false,
                    subs = loaded.subs,
                    excluded = emptySet(),
                    loadErrors = loaded.errors,
                )
            }
        }
    }

    fun toggleSub(key: String) = mutate {
        it.copy(excluded = if (key in it.excluded) it.excluded - key else it.excluded + key)
    }

    fun setAllSubs(selected: Boolean) = mutate {
        it.copy(excluded = if (selected) emptySet() else it.subs.map { s -> s.key }.toSet())
    }

    fun setPrefix(v: String) = mutate { it.copy(prefix = v) }
    fun setStart(v: String) = mutate { it.copy(start = v.filter { c -> c.isDigit() }.take(4)) }
    fun setPad(v: Boolean) = mutate { it.copy(pad = v) }
    fun setUtf8(v: Boolean) = _state.update { it.copy(toUtf8 = v) }
    fun dismissResult() = _state.update { it.copy(result = null) }
    fun dismissError() = _state.update { it.copy(error = null) }

    fun applyChanges() {
        val s = _state.value
        val dir = s.dirUri ?: return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val result = withContext(Dispatchers.IO) { Renamer.apply(ctx, dir, s.rows, s.toUtf8) }
            val listing = withContext(Dispatchers.IO) { Folder.list(ctx, dir) }
            mutate {
                it.copy(
                    busy = false,
                    result = result,
                    videos = listing?.videos ?: it.videos,
                    dirNames = listing?.allNames ?: it.dirNames,
                )
            }
        }
    }
}
