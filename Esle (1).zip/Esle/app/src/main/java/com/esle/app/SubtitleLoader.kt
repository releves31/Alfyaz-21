package com.esle.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.github.junrar.Junrar
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.util.zip.ZipFile

/**
 * Seçilen dosyaları (tek tek altyazı ya da zip/rar/7z arşivi) önbelleğe çıkarır.
 * Arşivlerin içindeki yalnızca altyazı dosyaları alınır.
 */
object SubtitleLoader {
    data class Loaded(val subs: List<SubItem>, val errors: List<String>)

    fun load(ctx: Context, uris: List<Uri>): Loaded {
        val root = File(ctx.cacheDir, "subs").apply {
            deleteRecursively()
            mkdirs()
        }
        val subs = mutableListOf<SubItem>()
        val errors = mutableListOf<String>()

        uris.forEachIndexed { index, uri ->
            val name = displayName(ctx, uri)
            val ext = Formats.ext(name)
            val work = File(root, "src$index").apply { mkdirs() }
            try {
                when {
                    ext in Formats.subtitle -> {
                        val f = File(work, safeName(name))
                        copyTo(ctx, uri, f)
                        subs += SubItem(name, f, name)
                    }
                    ext in Formats.archive -> {
                        val archive = File(work, "archive.$ext")
                        copyTo(ctx, uri, archive)
                        val out = File(work, "out").apply { mkdirs() }
                        when (ext) {
                            "zip" -> unzip(archive, out)
                            "rar" -> Junrar.extract(archive, out)
                            "7z" -> un7z(archive, out)
                        }
                        archive.delete()
                        val found = out.walkTopDown()
                            .filter { it.isFile && Formats.ext(it.name) in Formats.subtitle }
                            .toList()
                        if (found.isEmpty()) errors += "$name: içinde altyazı bulunamadı"
                        found.forEach { subs += SubItem(it.name, it, it.relativeTo(out).path + "  ·  " + name) }
                    }
                    else -> errors += "$name: desteklenmeyen biçim"
                }
            } catch (e: Exception) {
                errors += "$name: ${friendly(e)}"
            }
        }
        return Loaded(subs, errors)
    }

    private fun friendly(e: Exception): String {
        val cls = e.javaClass.simpleName
        return if (cls.contains("V5")) {
            "RAR5 biçimi desteklenmiyor (arşivi zip/7z olarak yeniden paketleyin)"
        } else {
            e.message ?: cls
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) {
                val n = it.getString(0)
                if (!n.isNullOrBlank()) return n
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "dosya"
    }

    private fun safeName(name: String) = name.replace(Regex("""[\\/:*?"<>|]"""), "_")

    private fun copyTo(ctx: Context, uri: Uri, dest: File) {
        val input = ctx.contentResolver.openInputStream(uri) ?: error("Dosya açılamadı")
        input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
    }

    /** Arşiv içinden dışarı yazmayı (zip-slip) engeller. */
    private fun safeDest(out: File, entryName: String): File? {
        val dest = File(out, entryName)
        return if (dest.canonicalPath.startsWith(out.canonicalPath + File.separator)) dest else null
    }

    private fun unzip(archive: File, out: File) {
        val zip = try {
            ZipFile(archive)
        } catch (e: Exception) {
            ZipFile(archive, Charsets.ISO_8859_1)
        }
        zip.use { z ->
            z.entries().asSequence()
                .filter { !it.isDirectory && Formats.ext(it.name) in Formats.subtitle }
                .forEach { entry ->
                    val dest = safeDest(out, entry.name) ?: return@forEach
                    dest.parentFile?.mkdirs()
                    z.getInputStream(entry).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                }
        }
    }

    private fun un7z(archive: File, out: File) {
        SevenZFile.builder().setFile(archive).get().use { sz ->
            val buf = ByteArray(16 * 1024)
            var entry = sz.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && Formats.ext(entry.name) in Formats.subtitle) {
                    val dest = safeDest(out, entry.name)
                    if (dest != null) {
                        dest.parentFile?.mkdirs()
                        dest.outputStream().use { o ->
                            while (true) {
                                val n = sz.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                            }
                        }
                    }
                }
                entry = sz.nextEntry
            }
        }
    }
}
